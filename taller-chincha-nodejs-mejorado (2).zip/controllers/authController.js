const db = require('../models/db');
const bcrypt = require('bcryptjs');

exports.loginPage = (req, res) => {
  res.render('login', { error: null });
};

exports.login = (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
    if (err || results.length === 0) {
      return res.render('login', { error: 'Usuario no encontrado' });
    }
    const user = results[0];
    if (await bcrypt.compare(password, user.password)) {
      req.session.user = user;
      res.redirect('/products');
    } else {
      res.render('login', { error: 'Contraseña incorrecta' });
    }
  });
};

exports.logout = (req, res) => {
  req.session.destroy(() => res.redirect('/'));
};