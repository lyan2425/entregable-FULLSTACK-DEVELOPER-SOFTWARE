const db = require('../models/db');

exports.list = (req, res) => {
  db.query('SELECT * FROM products', (err, results) => {
    if (err) throw err;
    res.render('products', { products: results });
  });
};

exports.addForm = (req, res) => {
  res.render('addProduct');
};

exports.add = (req, res) => {
  const { name, price } = req.body;
  db.query('INSERT INTO products (name, price) VALUES (?, ?)', [name, price], err => {
    if (err) throw err;
    res.redirect('/products');
  });
};

exports.editForm = (req, res) => {
  db.query('SELECT * FROM products WHERE id = ?', [req.params.id], (err, results) => {
    if (err) throw err;
    res.render('editProduct', { product: results[0] });
  });
};

exports.edit = (req, res) => {
  const { name, price } = req.body;
  db.query('UPDATE products SET name = ?, price = ? WHERE id = ?', [name, price, req.params.id], err => {
    if (err) throw err;
    res.redirect('/products');
  });
};

exports.delete = (req, res) => {
  db.query('DELETE FROM products WHERE id = ?', [req.params.id], err => {
    if (err) throw err;
    res.redirect('/products');
  });
};