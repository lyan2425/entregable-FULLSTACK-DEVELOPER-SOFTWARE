const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { isAuthenticated } = require('../middlewares/authMiddleware');

router.get('/', isAuthenticated, productController.list);
router.get('/add', isAuthenticated, productController.addForm);
router.post('/add', isAuthenticated, productController.add);
router.get('/edit/:id', isAuthenticated, productController.editForm);
router.post('/edit/:id', isAuthenticated, productController.edit);
router.get('/delete/:id', isAuthenticated, productController.delete);

module.exports = router;