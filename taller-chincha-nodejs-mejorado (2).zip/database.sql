CREATE DATABASE IF NOT EXISTS taller_db;
USE taller_db;

-- Tabla de usuarios
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Usuario de ejemplo (contraseña: 123456)
INSERT INTO users (email, password) VALUES (
    'admin@demo.com',
    '$2a$10$9JxWEMFZk6zOqBlztq2d5ebD5gOhpD2Ok.KW9cPb0Shlz2I1akNlC'
);

-- Tabla de productos
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);