const express = require('express');
const session = require('express-session');
const dotenv = require('dotenv');
const path = require('path');
const app = express();
dotenv.config();

// Middlewares
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true
}));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes
const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
app.use('/', authRoutes);
app.use('/products', productRoutes);

app.listen(3000, () => console.log("Servidor en http://localhost:3000"));